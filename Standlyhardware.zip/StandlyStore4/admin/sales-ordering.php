<?php require_once('header.php'); ?>

<section class="content-header">
	<div class="content-header-left">
		<h1>Ordering Sales Report</h1>
</div>
<div>
<button  style="float:right;" class="btn btn-success btn-large" onclick="window.print()"> Print</button></a>
</div>
</section>

<section class="content">
	<div class="row">
		<div class="col-md-12">
			<div class="box box-info">
				<div class="box-body table-responsive">
					<table id="example1" class="table table-bordered table-hover table-striped">
					<thead class="thead-dark">
							<tr>
								<th width="10">#</th>
								<th>Payment ID</th>
								<th width="160">Customer Name</th>
								<th width="60">Product Name</th>
								<th width="60">Price</th>
								<th width="60">Quantity</th>
								<th>Payment Date</th>
								<th>Paid Amount</th>
								<th>Payment Type</th>
                               

							</tr>
						</thead>
						<tbody>
							<?php
							$i=0;
							$statement = $pdo->prepare("SELECT
    
														t1.customer_name,
                                                        t1.payment_id,
														t2.product_name,
														t2.unit_price,
                                                        t2.quantity,
                                                        t1.payment_date,
                                                        t1.paid_amount,
                                                        t1.payment_method
                                                       
                                                        FROM tbl_payment AS t1, tbl_order AS t2 WHERE t1.payment_id = t2.payment_id ORDER BY payment_id DESC");
													
	
							$statement->execute();
							$result = $statement->fetchAll(PDO::FETCH_ASSOC);
							foreach ($result as $row) {
								$i++;
								?>
								<tr>
									<td><?php echo $i; ?></td>
                                    <td><?php echo $row['payment_id']; ?></td>
									<td><?php echo $row['customer_name']; ?></td>
                                    <td><?php echo $row['product_name']; ?></td>
									<td>₱<?php echo formatMoney ($row['unit_price'], true); ?></td>
									<td><?php echo $row['quantity']; ?></td>
									<td><?php echo $row['payment_date']; ?></td>
                                    <td>₱<?php echo formatMoney ($row['paid_amount'], true); ?></td>
									<td><?php echo $row['payment_method']; ?></td>
                                    </td>
                            </tr>
										
								<?php
							}
							?>							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>


<?php require_once('footer.php'); ?>